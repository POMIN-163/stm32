#ifndef _BEEP_H_
#define _BEEP_H_

#define BEEP PFout(8)


void beep_Init(void);


#endif
