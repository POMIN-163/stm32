#ifndef __PROGRESS_WIN_H__
#define __PROGRESS_WIN_H__
#include "sys.h"
#include "lvgl.h"




//��������
void progress_win_create(lv_obj_t * parent);





#endif

