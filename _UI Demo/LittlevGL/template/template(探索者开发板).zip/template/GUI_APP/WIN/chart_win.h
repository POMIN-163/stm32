#ifndef __CHART_WIN_H__
#define __CHART_WIN_H__
#include "sys.h"
#include "lvgl.h"






//��������
void chart_win_create(lv_obj_t * parent);



#endif

