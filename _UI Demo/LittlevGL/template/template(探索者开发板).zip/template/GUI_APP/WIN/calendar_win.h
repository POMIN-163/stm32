#ifndef __CALENDAR_WIN_H__
#define __CALENDAR_WIN_H__
#include "sys.h"
#include "lvgl.h"






//��������
void calendar_win_create(lv_obj_t * parent);


#endif

